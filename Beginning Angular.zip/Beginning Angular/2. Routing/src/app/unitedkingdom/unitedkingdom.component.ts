import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unitedkingdom',
  templateUrl: './unitedkingdom.component.html',
  styleUrls: ['./unitedkingdom.component.scss']
})
export class UnitedkingdomComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
