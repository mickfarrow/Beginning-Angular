export interface INewsItem {
    id: number;
    author:string;
    title:string;
    article:string;
}
